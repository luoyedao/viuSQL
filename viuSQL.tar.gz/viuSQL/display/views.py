from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, 'index.html')

def online_pp(request):
    return render(request, 'online.html')
def areas(request):
    return render(request, 'areas.html')

def percent(request):
    return render(request, 'percent.html')

def history(request):
    return render(request, 'history.html')
