#!/usr/bin/env python
from pandas import DataFrame,Series
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import MySQLdb
import time

mysql_cn= MySQLdb.connect(host='localhost', port=3306,user='root', passwd='',db='gamedb',charset='utf8')

def percent():
    mysql_cn= MySQLdb.connect(host='localhost', port=3306,user='root', passwd='',db='gamedb',charset='utf8')
    df = pd.read_sql('select sum(session_count),session_serverid from pp_online_count group by session_serverid',mysql_cn)
    data=df['sum(session_count)']
    labes=df['session_serverid']
    plt.figure(num=1, figsize=(8, 6))
    plt.axes(aspect=1)
    plt.title('persicent ', size=14)
    plt.pie(data, labels=labes)
    plt.savefig('static/percent.png', format='png')
    mysql_cn.commit()
def online_pp():
    mysql_cn= MySQLdb.connect(host='localhost', port=3306,user='root', passwd='',db='gamedb',charset='utf8')
    df = pd.read_sql('select online_time,session_count from pp_online_count order by online_time desc limit 1221',mysql_cn)
    df.index=df['online_time']
    display=df.plot().get_figure()
    display.savefig('static/online_time.png',format='png')
    mysql_cn.commit()
def history_tend():
    mysql_cn= MySQLdb.connect(host='localhost', port=3306,user='root', passwd='',db='gamedb',charset='utf8')
    df = pd.read_sql('select online_time ,session_count from pp_online_count',mysql_cn)
    df.index=df['online_time']
    display=df.plot().get_figure()
    display.savefig('static/history_tend.png',format='png')
    mysql_cn.commit()
def everycount():
    mysql_cn= MySQLdb.connect(host='localhost', port=3306,user='root', passwd='',db='gamedb',charset='utf8')
    df = pd.read_sql('select sum(session_count),session_serverid from pp_online_count group by session_serverid',mysql_cn)
    df.index=df['session_serverid']
    display=df.plot(kind='bar').get_figure()
    display.savefig('static/evercount.png',format='png')
    mysql_cn.commit()
while True:
    percent()
    time.sleep(20)
    online_pp()
    time.sleep(20)
    history_tend()
    time.sleep(20)
    everycount()
mysql_cn.close()
